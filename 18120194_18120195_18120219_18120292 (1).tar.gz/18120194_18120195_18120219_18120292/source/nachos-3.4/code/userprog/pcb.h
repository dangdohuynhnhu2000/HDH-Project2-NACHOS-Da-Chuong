#ifndef PCB_H
#define PCB_H

#include "thread.h"
#include "synch.h"

class PCB
{
private:
    Semaphore* joinsem;         // semaphore cho qua trinh join
    Semaphore* exitsem;         // semaphore cho qua trinh exit
    Semaphore* mutex;           // semaphore cho qua trinh truy xuat doc quyen  
    int exitcode;		
    int numwait;                // so tien trinh da join
    char FileName[32];          // ten cua tien trinh
    Thread* thread;            
public:
    int parentID;               // ID cua tien trinh cha
      
    PCB(int = 0);               
    ~PCB();                     

    int Exec(char* filename, int pID); //nap chuong trinh co ten luu trong bien filename va processID se la pID
    int GetID();               
    int GetNumWait();           //tra ve so luong tien trinh dang cho


    void JoinWait();            
    void ExitWait();             

    void JoinRelease();         
    void ExitRelease();         

    void IncNumWait();          
    void DecNumWait();          

    void SetExitCode(int);      //dat exit code cho tien trinh
    int GetExitCode();          //tra ve exit code

    void SetFileName(char*);    //dat ten tien trinh
    char* GetFileName();        //tra ve ten tien trinh

};

#endif // PCB_H
