#ifndef PTABLE_H
#define PTABLE_H

#include "bitmap.h"
#include "pcb.h"
#include "synch.h"

#define MAX_PROCESS 10

class PTable
{
private:
	int psize;
	BitMap *bm;  // dung de danh dau cac vi tri da duoc su dung trong bitmap
	PCB* pcb[MAX_PROCESS];
	Semaphore* bmsem; //ngan chan truong hop nap 2 tien trinh cung luc

public:
     PTable(int = MAX_PROCESS);        
    ~PTable();                  
		
    int ExecUpdate(char*);    //cap phat block moi, tra ve pID neu thanh cong
    int ExitUpdate(int);        
    int JoinUpdate(int);        

    int GetFreeSlot();        //tim slot trong o bang pTable de luu thong tin tien trinh moi
    bool IsExist(int pid);    //kiem tra su ton tai cua process ID 
    void Remove(int pid);     //xoa tien trinh co process ID tuong ung
    char* GetFileName(int id);//tra ve ten cua tien trinh
};
#endif // PTABLE_H

