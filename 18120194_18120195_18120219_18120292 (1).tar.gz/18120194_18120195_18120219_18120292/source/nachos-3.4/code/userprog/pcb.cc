#include "pcb.h"
#include "utility.h"
#include "system.h"
#include "thread.h"
#include "addrspace.h"


extern void MyStartProcess(int id);

PCB::PCB(int id)
{
	if (id == 0)
        	this->parentID = -1;
    	else
        	this->parentID = currentThread->processID;

   	this->numwait = 0;
   	this->exitcode = 0;
   	this->thread = NULL;

   	this->joinsem = new Semaphore("joinsem",0);
   	this->exitsem = new Semaphore("exitsem",0);
   	this->mutex = new Semaphore("mutex",1);
}

PCB::~PCB()
{
	
	if(joinsem != NULL)
		delete this->joinsem;
	if(exitsem != NULL)
		delete this->exitsem;
	if(mutex != NULL)
		delete this->mutex;

}

int PCB::GetID()
{ 
	return thread->processID; 
}

int PCB::GetNumWait() 
{ 
	return numwait; 
}

int PCB::GetExitCode() 
{ 
	return exitcode; 
}

void PCB::SetExitCode(int ec)
{ 
	this->exitcode = ec; 
}


void PCB::JoinWait()
{
    //thuc hien chuyen tien trinh sang trang thai block va ngung lai, 
    //cho JoinRelease() de thuc hien tiep
    joinsem->P();
}


void PCB::JoinRelease()
{ 
    //giai phong tien trinh goi JoinWait()
    joinsem->V();
}


void PCB::ExitWait()
{ 
    //thuc hien chuyen tien trinh sang trang thai block va ngung lai, cho ExitRelease() de thuc hien tiep
    exitsem->P();
}


void PCB::ExitRelease() 
{	
    //giai phong tien trinh dang cho
    exitsem->V();
}

//tang so tien trinh da join
void PCB::IncNumWait()
{
	mutex->P();
	numwait++;
	mutex->V();
}

//giam so tien trinh da join
void PCB::DecNumWait()
{
	mutex->P();
	if(numwait > 0)
		numwait--;
	mutex->V();
}

void PCB::SetFileName(char* filename)
{ 
	strcpy(FileName,filename);
}

char* PCB::GetFileName() 
{ 
	return this->FileName; 
}

int PCB::Exec(char* filename, int id)
{  
	//tranh tinh trang 2 tien trinh nap cung luc
	mutex->P();

	//tao 1 thread moi            
	this->thread = new Thread(filename);

	if(this->thread == NULL){
		printf("\nPCB::Exec:: Not enough memory..!\n");
        	mutex->V();
		return -1;
	}

	
	this->thread->processID = id;

	this->parentID = currentThread->processID;
	
	//khoi tao cac thong tin can thiet cho mot tieu trinh va dua no vao 
	//CPU de thuc hien
 	this->thread->Fork(MyStartProcess,id);

    	mutex->V();

	return id;

}
