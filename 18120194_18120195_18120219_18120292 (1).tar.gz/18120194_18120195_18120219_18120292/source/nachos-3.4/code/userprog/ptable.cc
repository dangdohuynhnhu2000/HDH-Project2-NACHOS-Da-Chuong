#include "ptable.h"
#include "system.h"
#include "openfile.h"

PTable::PTable(int size)
{

    if (size < 0)
        return;

//gan kich thuoc cho bang ptable
    psize = size;
    bm = new BitMap(size);
    bmsem = new Semaphore("bmsem",1);

//gan cac gia tri ban dau bang 0
    for(int i = 0; i < MAX_PROCESS; i++)
    {
		pcb[i] = 0;
    }


//tien trinh cha ban dau
	bm->Mark(0);

	pcb[0] = new PCB(0);
	pcb[0]->SetFileName("./test/scheduler");
	pcb[0]->parentID = -1;
}

PTable::~PTable()
{
    if( bm != 0 )
	delete bm;
    
    for(int i=0; i<psize; i++)
    {
		if(pcb[i] != 0)
			delete pcb[i];
    }
		
	if( bmsem != 0)
		delete bmsem;
}

int PTable::ExecUpdate(char* name)
{
	bmsem->P();
	
	//kiem tra file co ton tai hay khong
	OpenFile *executable = fileSystem->Open(name);
	if (executable == NULL) 
	{
		printf("\nUnable to open file %s\n", name);
		bmsem->V();
		return -1;
    	}
	delete executable;
	

	//dam bao chuong trinh khong goi thuc thi chinh no
	if( strcmp(name,"./test/scheduler") == 0 || strcmp(name,currentThread->getName()) == 0 )
	{
		printf("\nPTable::Exec : Can't not execute itself.\n");		
		bmsem->V();
		return -1;
	}

	// tim slot con trong o bang pTable
	int index = this->GetFreeSlot();

    	//neu khong con slot trong thi thong bao va ket thuc
	if(index == -1)
	{
		printf("\nPTable::Exec :There is no free slot.\n");
		bmsem->V();
		return -1;
	}

	//neu co slot trong thi tao 1 pcb moi voi process_id bang index
	pcb[index] = new PCB(index);
	pcb[index]->SetFileName(name);

	// parrentID cua pcb moi nay chinh la processID cua currentThread
    	pcb[index]->parentID = currentThread->processID;
	
	int pid = pcb[index]->Exec(name,index);

	bmsem->V();

	return pid;
}

int PTable::JoinUpdate(int id)
{
	if(id < 0 || id > 9)
	{
		printf("\nPTable::JoinUpdate : id = %d", id);
		return -1;
	}

	//kiem tra xem tien trinh co join vao tien trinh cha cua no hay khong
	if(currentThread->processID != pcb[id]->parentID)
	{
		printf("\nPTable::JoinUpdate Can't join in process which is not it's parent process.\n");
		return -1;
	}

    	//tang so tien trinh dang cho
	pcb[pcb[id]->parentID]->IncNumWait();
	
	//tien trinh cha doi tien trinh con ket thuc
	pcb[id]->JoinWait();
	
	int ec = pcb[id]->GetExitCode();
        
	//cho phep tien trinh con thoat
	pcb[id]->ExitRelease();

	return ec;
}


int PTable::ExitUpdate(int exitcode)
{              
    // neu tien trinh goi la main process thi goi ham ket thuc Halt()
	int id = currentThread->processID;
	if(id == 0)
	{	
		currentThread->FreeSpace();		
		interrupt->Halt();
		return 0;
	}
    
        if(IsExist(id) == false)
	{
		printf("\nPTable::ExitUpdate: This %d is not exist. Try again?", id);
		return -1;
	}
	
	//neu khong phai la main process thi dat exitcode cho no
	pcb[id]->SetExitCode(exitcode);

	//giam so tien trinh da join
	pcb[pcb[id]->parentID]->DecNumWait();
    
    	//giai phong tien trinh cha dang doi no (neu co)
	pcb[id]->JoinRelease();
    	
	//xin tien trinh cha cho phep thoat
	pcb[id]->ExitWait();
	
	Remove(id);
	return exitcode;
}

//tim slot trong o bang pTable
int PTable::GetFreeSlot()
{
	return bm->Find();
}

bool PTable::IsExist(int pid)
{
	return bm->Test(pid);
}

//xoa process ID ra khoi bitmap va xoa tien trinh co process ID tuong ung
void PTable::Remove(int pid)
{
	bm->Clear(pid);
	if(pcb[pid] != 0)
		delete pcb[pid];
}

//lay ten cua tien trinh
char* PTable::GetFileName(int id)
{
	return (pcb[id]->GetFileName());
}

