int
main()
{
    PrintString("****************************************************\n**               DO AN HE DIEU HANH               **\n");
    PrintString("**        Tran Thi Thuy Linh   -  18120194        **\n**        Vuong Thi Ngoc Linh  -  18120195        **\n**        Dang Do Huynh Nhu    -  18120219        **\n**        Nguyen Duong Binl    -  18120292        **\n");
    PrintString("****************************************************\n");
    PrintString("                 CHUONG TRINH SORT\n");
    PrintString("Chuong trinh cho phep nguoi dung nhap vao mang n so nguyen, voi n la so nguyen nho hon bang 100 do nguoi dung nhap vao.\nTiep do tuy theo lua chon cua nguoi dung ma chuong trinh se in ra mang so nguyen da duoc sap xep thu tu tang dan hoac giam dan.\n");
    PrintString("****************************************************\n");
    PrintString("                 CHUONG TRINH ASCII\nChuong trinh in ra cac ki tu doc duoc tu bang ma ASCII\n");
    PrintString("****************************************************\n");
    Halt();

}
